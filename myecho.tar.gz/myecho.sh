#!/bin/bash
echo "this is myecho message."
